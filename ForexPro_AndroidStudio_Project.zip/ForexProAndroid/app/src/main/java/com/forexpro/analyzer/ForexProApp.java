package com.forexpro.analyzer;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.appcompat.app.AppCompatDelegate;
import com.forexpro.analyzer.utils.PreferenceManager;

public class ForexProApp extends Application {

    public static final String CHANNEL_SIGNALS = "forex_signals";
    public static final String CHANNEL_NEWS    = "forex_news";
    public static final String CHANNEL_ALERTS  = "forex_alerts";

    private static ForexProApp instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        applyTheme();
        createNotificationChannels();
    }

    public static ForexProApp getInstance() { return instance; }
    public static Context getCtx()          { return instance.getApplicationContext(); }

    private void applyTheme() {
        PreferenceManager prefs = new PreferenceManager(this);
        boolean isDark = prefs.isDarkMode();
        AppCompatDelegate.setDefaultNightMode(
            isDark ? AppCompatDelegate.MODE_NIGHT_YES
                   : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            NotificationChannel signals = new NotificationChannel(
                CHANNEL_SIGNALS, "Forex Signals",
                NotificationManager.IMPORTANCE_HIGH);
            signals.setDescription("BUY/SELL signal alerts");
            signals.enableVibration(true);
            signals.setVibrationPattern(new long[]{0, 250, 250, 250});

            NotificationChannel news = new NotificationChannel(
                CHANNEL_NEWS, "Market News",
                NotificationManager.IMPORTANCE_DEFAULT);
            news.setDescription("High-impact economic news");

            NotificationChannel alerts = new NotificationChannel(
                CHANNEL_ALERTS, "Price Alerts",
                NotificationManager.IMPORTANCE_HIGH);
            alerts.setDescription("Custom price level alerts");

            nm.createNotificationChannel(signals);
            nm.createNotificationChannel(news);
            nm.createNotificationChannel(alerts);
        }
    }
}
