package com.forexpro.analyzer.engine;

import com.forexpro.analyzer.models.ForexSignal;
import java.util.*;

/**
 * SignalEngine.java
 * Connects ForexMathEngine to produce complete ForexSignal objects
 */
public class SignalEngine {

    private static final Map<String, double[]> PAIR_DEFAULTS = new HashMap<String, double[]>() {{
        // pair → [basePrice, pip, spread]
        put("EUR/USD", new double[]{1.0892, 0.0001, 2});
        put("GBP/USD", new double[]{1.2634, 0.0001, 3});
        put("USD/JPY", new double[]{149.82, 0.01,   3});
        put("USD/CAD", new double[]{1.3521, 0.0001, 3});
        put("AUD/USD", new double[]{0.6542, 0.0001, 2});
        put("NZD/USD", new double[]{0.6015, 0.0001, 3});
        put("EUR/GBP", new double[]{0.8623, 0.0001, 2});
        put("USD/CHF", new double[]{0.8934, 0.0001, 3});
        put("EUR/JPY", new double[]{163.24, 0.01,   4});
        put("GBP/JPY", new double[]{189.12, 0.01,   5});
    }};

    /**
     * Generate a complete ForexSignal for a given pair and timeframe
     */
    public static ForexSignal generateSignal(String pair, String timeframe) {
        double[] config = PAIR_DEFAULTS.getOrDefault(pair,
            new double[]{1.0, 0.0001, 2});

        double basePrice = config[0];
        double pip       = config[1];

        // Simulate realistic OHLC data
        int bars = 250;
        double[] closes = simulatePrices(basePrice, pip, bars);
        double[] highs  = simulateHighs(closes, pip);
        double[] lows   = simulateLows(closes, pip);
        double[] opens  = simulateOpens(closes);

        // ── Run all indicators ──────────────────────────────────────
        double rsiVal     = ForexMathEngine.rsi(closes, 14);
        double[] macdVals = ForexMathEngine.macd(closes);
        double[] ema20arr = ForexMathEngine.ema(closes, 20);
        double[] ema50arr = ForexMathEngine.ema(closes, 50);
        double[] ema200arr= ForexMathEngine.ema(closes, 200);
        double[] bbVals   = ForexMathEngine.bollingerBands(closes, 20, 2.0);
        double[] stoch    = ForexMathEngine.stochastic(highs, lows, closes, 14);
        double[] adxVals  = ForexMathEngine.adx(highs, lows, closes, 14);
        double atrVal     = ForexMathEngine.atr(highs, lows, closes, 14);
        double slopeVal   = ForexMathEngine.slope(closes, 20);
        double trendAng   = ForexMathEngine.trendAngle(closes, 20);
        double cciVal     = ForexMathEngine.cci(highs, lows, closes, 20);
        double willR      = ForexMathEngine.williamsR(highs, lows, closes, 14);
        double[] fibLvls  = ForexMathEngine.fibonacciRetracement(
                               max(highs, 50), min(lows, 50));
        double[] pivots   = ForexMathEngine.classicPivot(
                               highs[bars-1], lows[bars-1], closes[bars-1]);

        // ── Compound signal ─────────────────────────────────────────
        double[] signalResult = ForexMathEngine.compoundSignal(closes, highs, lows, 20);
        int direction      = (int) signalResult[0];
        double confidence  = signalResult[1];

        // ── Build signal object ─────────────────────────────────────
        ForexSignal signal = new ForexSignal();
        signal.pair         = pair;
        signal.timeframe    = timeframe;
        signal.signal       = direction > 0 ? "BUY" : (direction < 0 ? "SELL" : "HOLD");
        signal.confidence   = confidence;
        signal.entry        = closes[bars - 1];
        signal.rsi          = rsiVal;
        signal.macdLine     = macdVals[0];
        signal.macdHistogram= macdVals[2];
        signal.ema20        = ema20arr[bars - 1];
        signal.ema50        = ema50arr[bars - 1];
        signal.ema200       = ema200arr[bars - 1];
        signal.bbUpper      = bbVals[0];
        signal.bbMiddle     = bbVals[1];
        signal.bbLower      = bbVals[2];
        signal.bbPctB       = bbVals[4];
        signal.stochK       = stoch[0];
        signal.stochD       = stoch[1];
        signal.adx          = adxVals[0];
        signal.plusDI       = adxVals[1];
        signal.minusDI      = adxVals[2];
        signal.atrValue     = atrVal;
        signal.slopeValue   = slopeVal;
        signal.trendAngle   = trendAng;
        signal.fibLevels    = fibLvls;
        signal.pivotLevels  = pivots;

        // ── TP / SL based on ATR ────────────────────────────────────
        double tpMultiplier = 2.5;
        double slMultiplier = 1.5;
        if (signal.isBuy()) {
            signal.takeProfit = signal.entry + atrVal * tpMultiplier;
            signal.stopLoss   = signal.entry - atrVal * slMultiplier;
        } else if (signal.isSell()) {
            signal.takeProfit = signal.entry - atrVal * tpMultiplier;
            signal.stopLoss   = signal.entry + atrVal * slMultiplier;
        } else {
            signal.takeProfit = signal.entry + atrVal * 2.0;
            signal.stopLoss   = signal.entry - atrVal * 1.5;
        }
        signal.tpPips = (int)(Math.abs(signal.takeProfit - signal.entry) / pip);
        signal.slPips = (int)(Math.abs(signal.entry - signal.stopLoss) / pip);
        signal.rrRatio = ForexMathEngine.riskRewardRatio(
            signal.entry, signal.takeProfit, signal.stopLoss);

        // ── Analysis text ───────────────────────────────────────────
        signal.analysisText = buildAnalysisText(signal, cciVal, willR);
        signal.timestamp    = System.currentTimeMillis();

        return signal;
    }

    private static String buildAnalysisText(ForexSignal s, double cci, double willR) {
        StringBuilder sb = new StringBuilder();

        // Trend
        sb.append(s.pair).append(" ").append(s.timeframe).append(" Analysis:\n\n");

        // RSI
        if (s.rsi < 30)      sb.append("• RSI(14): ").append(String.format("%.1f", s.rsi)).append(" — OVERSOLD zone, potential reversal ↑\n");
        else if (s.rsi > 70) sb.append("• RSI(14): ").append(String.format("%.1f", s.rsi)).append(" — OVERBOUGHT zone, potential reversal ↓\n");
        else                  sb.append("• RSI(14): ").append(String.format("%.1f", s.rsi)).append(s.rsi > 50 ? " — Bullish momentum ↑\n" : " — Bearish momentum ↓\n");

        // MACD
        sb.append("• MACD Histogram: ").append(String.format("%.5f", s.macdHistogram))
          .append(s.macdHistogram > 0 ? " — Bullish divergence ↑\n" : " — Bearish divergence ↓\n");

        // EMAs
        sb.append("• EMA 20 ").append(s.ema20 > s.ema50 ? ">" : "<").append(" EMA 50 — ")
          .append(s.ema20 > s.ema50 ? "Golden Cross (Bullish)\n" : "Death Cross (Bearish)\n");

        // ADX
        sb.append("• ADX: ").append(String.format("%.1f", s.adx))
          .append(s.adx > 25 ? " — Strong trend " : " — Weak/Ranging ")
          .append(s.plusDI > s.minusDI ? "(+DI dominant, Bullish)\n" : "(-DI dominant, Bearish)\n");

        // Bollinger
        sb.append("• Bollinger %B: ").append(String.format("%.1f%%", s.bbPctB * 100))
          .append(s.bbPctB < 0.2 ? " — Near lower band (Buy zone)\n" :
                  s.bbPctB > 0.8 ? " — Near upper band (Sell zone)\n" : " — Mid-range\n");

        // CCI
        sb.append("• CCI: ").append(String.format("%.1f", cci))
          .append(cci > 100 ? " — Overbought\n" : cci < -100 ? " — Oversold\n" : " — Neutral\n");

        // Trend angle
        sb.append("• Trend Angle: ").append(String.format("%.1f°", s.trendAngle))
          .append(Math.abs(s.trendAngle) > 15 ? " — Strong trend\n" : " — Weak trend\n");

        // Conclusion
        sb.append("\n🎯 Signal: ").append(s.signal)
          .append(" | Confidence: ").append(String.format("%.0f%%", s.confidence))
          .append(" | R:R = 1:").append(String.format("%.2f", s.rrRatio));

        return sb.toString();
    }

    // ── Helpers ─────────────────────────────────────────────────────

    private static double[] simulatePrices(double base, double pip, int bars) {
        Random rnd = new Random();
        double[] prices = new double[bars];
        prices[0] = base;
        for (int i = 1; i < bars; i++) {
            double change = (rnd.nextGaussian() * pip * 8);
            prices[i] = Math.max(base * 0.85, prices[i-1] + change);
        }
        return prices;
    }

    private static double[] simulateHighs(double[] closes, double pip) {
        Random rnd = new Random();
        double[] highs = new double[closes.length];
        for (int i = 0; i < closes.length; i++) {
            highs[i] = closes[i] + pip * (2 + rnd.nextInt(15));
        }
        return highs;
    }

    private static double[] simulateLows(double[] closes, double pip) {
        Random rnd = new Random();
        double[] lows = new double[closes.length];
        for (int i = 0; i < closes.length; i++) {
            lows[i] = closes[i] - pip * (2 + rnd.nextInt(15));
        }
        return lows;
    }

    private static double[] simulateOpens(double[] closes) {
        double[] opens = new double[closes.length];
        opens[0] = closes[0];
        for (int i = 1; i < closes.length; i++) opens[i] = closes[i-1];
        return opens;
    }

    private static double max(double[] arr, int last) {
        double m = arr[arr.length - last];
        for (int i = arr.length - last; i < arr.length; i++) if (arr[i] > m) m = arr[i];
        return m;
    }

    private static double min(double[] arr, int last) {
        double m = arr[arr.length - last];
        for (int i = arr.length - last; i < arr.length; i++) if (arr[i] < m) m = arr[i];
        return m;
    }
}
