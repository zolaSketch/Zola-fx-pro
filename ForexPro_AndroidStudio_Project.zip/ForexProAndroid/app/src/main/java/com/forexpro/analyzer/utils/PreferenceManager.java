package com.forexpro.analyzer.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static final String PREF_NAME   = "forex_pro_prefs";
    private static final String KEY_DARK    = "dark_mode";
    private static final String KEY_LANG    = "language";
    private static final String KEY_NOTIFY  = "notifications";
    private static final String KEY_BALANCE = "account_balance";
    private static final String KEY_RISK    = "risk_percent";

    private final SharedPreferences prefs;

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isDarkMode()   { return prefs.getBoolean(KEY_DARK, true); }
    public void setDarkMode(boolean d) { prefs.edit().putBoolean(KEY_DARK, d).apply(); }

    public String getLanguage()   { return prefs.getString(KEY_LANG, "en"); }
    public void setLanguage(String l) { prefs.edit().putString(KEY_LANG, l).apply(); }

    public boolean isNotificationsEnabled() { return prefs.getBoolean(KEY_NOTIFY, true); }
    public void setNotifications(boolean n) { prefs.edit().putBoolean(KEY_NOTIFY, n).apply(); }

    public double getAccountBalance() { return Double.longBitsToDouble(prefs.getLong(KEY_BALANCE, Double.doubleToLongBits(10000.0))); }
    public void setAccountBalance(double b) { prefs.edit().putLong(KEY_BALANCE, Double.doubleToLongBits(b)).apply(); }

    public double getRiskPercent() { return Double.longBitsToDouble(prefs.getLong(KEY_RISK, Double.doubleToLongBits(1.0))); }
    public void setRiskPercent(double r) { prefs.edit().putLong(KEY_RISK, Double.doubleToLongBits(r)).apply(); }
}
