package com.forexpro.analyzer.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.engine.SignalEngine;
import com.forexpro.analyzer.models.ForexSignal;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.*;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.ValueFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SignalsFragment extends Fragment {

    private static final String[] PAIRS = {
        "EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD","NZD/USD","EUR/GBP","USD/CHF"
    };
    private static final String[] TIMEFRAMES = {"M15","H1","H4","D1"};

    private String currentPair = "EUR/USD";
    private String currentTf   = "H1";
    private ForexSignal currentSignal;

    // UI Elements
    private TextView tvPairName, tvSignalType, tvConfidence;
    private TextView tvEntry, tvTp, tvSl, tvRrr;
    private TextView tvRsi, tvMacd, tvAdx, tvBb, tvStoch, tvEma;
    private TextView tvAnalysis, tvTpPips, tvSlPips;
    private ProgressBar progressSignal;
    private LinearLayout signalCard;
    private LineChart priceChart;
    private Button btnAnalyze;
    private Spinner spinnerPair, spinnerTf;
    private ScrollView scrollView;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signals, container, false);
        bindViews(view);
        setupSpinners();
        setupChart();
        runAnalysis();
        return view;
    }

    private void bindViews(View v) {
        tvPairName    = v.findViewById(R.id.tvPairName);
        tvSignalType  = v.findViewById(R.id.tvSignalType);
        tvConfidence  = v.findViewById(R.id.tvConfidence);
        tvEntry       = v.findViewById(R.id.tvEntry);
        tvTp          = v.findViewById(R.id.tvTp);
        tvSl          = v.findViewById(R.id.tvSl);
        tvRrr         = v.findViewById(R.id.tvRrr);
        tvTpPips      = v.findViewById(R.id.tvTpPips);
        tvSlPips      = v.findViewById(R.id.tvSlPips);
        tvRsi         = v.findViewById(R.id.tvRsi);
        tvMacd        = v.findViewById(R.id.tvMacd);
        tvAdx         = v.findViewById(R.id.tvAdx);
        tvBb          = v.findViewById(R.id.tvBb);
        tvStoch       = v.findViewById(R.id.tvStoch);
        tvEma         = v.findViewById(R.id.tvEma);
        tvAnalysis    = v.findViewById(R.id.tvAnalysis);
        progressSignal= v.findViewById(R.id.progressSignal);
        signalCard    = v.findViewById(R.id.signalCard);
        priceChart    = v.findViewById(R.id.priceChart);
        btnAnalyze    = v.findViewById(R.id.btnAnalyze);
        spinnerPair   = v.findViewById(R.id.spinnerPair);
        spinnerTf     = v.findViewById(R.id.spinnerTf);

        btnAnalyze.setOnClickListener(v2 -> runAnalysis());
    }

    private void setupSpinners() {
        ArrayAdapter<String> pairAdapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_spinner_item, PAIRS);
        pairAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPair.setAdapter(pairAdapter);
        spinnerPair.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int i, long id) {
                currentPair = PAIRS[i];
                runAnalysis();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        ArrayAdapter<String> tfAdapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_spinner_item, TIMEFRAMES);
        tfAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTf.setAdapter(tfAdapter);
        spinnerTf.setSelection(1); // Default H1
        spinnerTf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int i, long id) {
                currentTf = TIMEFRAMES[i];
                runAnalysis();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    private void runAnalysis() {
        showLoading(true);
        executor.execute(() -> {
            ForexSignal signal = SignalEngine.generateSignal(currentPair, currentTf);
            mainHandler.post(() -> {
                currentSignal = signal;
                updateUI(signal);
                updateChart(signal);
                showLoading(false);
            });
        });
    }

    private void updateUI(ForexSignal s) {
        boolean isJpy = s.pair.contains("JPY");
        int dp = isJpy ? 3 : 5;
        String fmt = "%." + dp + "f";

        tvPairName.setText(s.pair);
        tvSignalType.setText(s.signal);
        tvConfidence.setText(String.format("%.0f%%", s.confidence));

        tvEntry.setText(String.format(fmt, s.entry));
        tvTp.setText(String.format(fmt, s.takeProfit));
        tvSl.setText(String.format(fmt, s.stopLoss));
        tvTpPips.setText("+" + s.tpPips + " pips");
        tvSlPips.setText("-" + s.slPips + " pips");
        tvRrr.setText(String.format("1 : %.2f", s.rrRatio));

        tvRsi.setText(String.format("RSI: %.1f — %s", s.rsi,
            s.rsi > 70 ? "OVERBOUGHT" : s.rsi < 30 ? "OVERSOLD" : s.rsi > 50 ? "BULLISH" : "BEARISH"));
        tvMacd.setText(String.format("MACD: %.5f (%s)",
            s.macdHistogram, s.macdHistogram > 0 ? "▲ BULLISH" : "▼ BEARISH"));
        tvAdx.setText(String.format("ADX: %.1f — %s", s.adx,
            s.adx > 25 ? (s.plusDI > s.minusDI ? "STRONG BULL" : "STRONG BEAR") : "RANGING"));
        tvBb.setText(String.format("Bollinger %%B: %.1f%%", s.bbPctB * 100));
        tvStoch.setText(String.format("Stoch %%K: %.1f — %s", s.stochK,
            s.stochK > 80 ? "OVERBOUGHT" : s.stochK < 20 ? "OVERSOLD" : "NEUTRAL"));
        tvEma.setText(String.format("EMA 20%s50 — %s",
            s.ema20 > s.ema50 ? ">" : "<",
            s.ema20 > s.ema50 ? "Golden Cross ↑" : "Death Cross ↓"));

        tvAnalysis.setText(s.analysisText);

        // Color signal card
        int bgColor, textColor;
        if (s.isBuy()) {
            bgColor   = 0xFF0D2A1A;
            textColor = 0xFF00FF88;
        } else if (s.isSell()) {
            bgColor   = 0xFF2A0D16;
            textColor = 0xFFFF3355;
        } else {
            bgColor   = 0xFF2A200D;
            textColor = 0xFFFF8C00;
        }
        if (signalCard != null) signalCard.setBackgroundColor(bgColor);
        if (tvSignalType != null) tvSignalType.setTextColor(textColor);
    }

    private void updateChart(ForexSignal signal) {
        if (priceChart == null) return;

        // Generate price data for chart
        Random rnd = new Random();
        double base = signal.entry;
        boolean isJpy = signal.pair.contains("JPY");
        double pip = isJpy ? 0.01 : 0.0001;

        List<Entry> entries = new ArrayList<>();
        double price = base * 0.995;
        for (int i = 0; i < 50; i++) {
            price += (rnd.nextGaussian() * pip * 8);
            entries.add(new Entry(i, (float) price));
        }
        entries.add(new Entry(50, (float) base));

        // EMA line
        List<Entry> emaEntries = new ArrayList<>();
        double ema = entries.get(0).getY();
        double mult = 2.0 / 21;
        for (Entry e : entries) {
            ema = e.getY() * mult + ema * (1 - mult);
            emaEntries.add(new Entry(e.getX(), (float) ema));
        }

        LineDataSet priceSet = new LineDataSet(entries, signal.pair);
        priceSet.setColor(signal.isBuy() ? 0xFF00FF88 : 0xFFFF3355);
        priceSet.setLineWidth(2f);
        priceSet.setDrawCircles(false);
        priceSet.setDrawValues(false);
        priceSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        priceSet.setDrawFilled(true);
        priceSet.setFillAlpha(30);
        priceSet.setFillColor(signal.isBuy() ? 0xFF00FF88 : 0xFFFF3355);

        LineDataSet emaSet = new LineDataSet(emaEntries, "EMA 20");
        emaSet.setColor(0xFFFFD700);
        emaSet.setLineWidth(1.5f);
        emaSet.setDrawCircles(false);
        emaSet.setDrawValues(false);
        emaSet.enableDashedLine(10f, 5f, 0f);

        LineData lineData = new LineData(priceSet, emaSet);
        priceChart.setData(lineData);

        // Style
        priceChart.setBackgroundColor(0xFF0D1E2E);
        priceChart.getDescription().setEnabled(false);
        priceChart.getLegend().setTextColor(0xFF5A8AAA);
        priceChart.getAxisRight().setEnabled(false);
        priceChart.getXAxis().setDrawGridLines(false);
        priceChart.getXAxis().setTextColor(0xFF5A8AAA);
        priceChart.getAxisLeft().setTextColor(0xFF5A8AAA);
        priceChart.getAxisLeft().setGridColor(0x1AFFFFFF);
        priceChart.setTouchEnabled(true);
        priceChart.setPinchZoom(true);
        priceChart.animateX(600);
        priceChart.invalidate();
    }

    private void showLoading(boolean loading) {
        if (progressSignal != null)
            progressSignal.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (btnAnalyze != null) {
            btnAnalyze.setEnabled(!loading);
            btnAnalyze.setText(loading ? "ANALYZING..." : "🔍 ANALYZE");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    // Stub fragments (each would have full implementation)
    private void setupChart() {
        if (priceChart == null) return;
        priceChart.setNoDataText("Select a pair to analyze");
        priceChart.setNoDataTextColor(0xFF5A8AAA);
    }
}
