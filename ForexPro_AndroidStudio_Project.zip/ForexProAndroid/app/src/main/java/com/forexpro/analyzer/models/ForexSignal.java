package com.forexpro.analyzer.models;

public class ForexSignal {
    public String pair;
    public String signal;        // BUY / SELL / HOLD
    public String timeframe;
    public double entry;
    public double takeProfit;
    public double stopLoss;
    public int tpPips;
    public int slPips;
    public double rrRatio;
    public double confidence;
    public double rsi;
    public double macdLine;
    public double macdHistogram;
    public double ema20, ema50, ema200;
    public double adx, plusDI, minusDI;
    public double stochK, stochD;
    public double bbUpper, bbMiddle, bbLower, bbPctB;
    public double atrValue;
    public double slopeValue;
    public double trendAngle;
    public double[] fibLevels;
    public double[] pivotLevels;
    public String analysisText;
    public String sentimentBias;
    public long timestamp;

    public boolean isBuy()  { return "BUY".equals(signal); }
    public boolean isSell() { return "SELL".equals(signal); }
    public boolean isHold() { return "HOLD".equals(signal); }

    public String getSignalEmoji() {
        if (isBuy())  return "🟢";
        if (isSell()) return "🔴";
        return "🟡";
    }

    public String getConfidenceLabel() {
        if (confidence >= 80) return "VERY STRONG";
        if (confidence >= 65) return "STRONG";
        if (confidence >= 50) return "MODERATE";
        return "WEAK";
    }
}
