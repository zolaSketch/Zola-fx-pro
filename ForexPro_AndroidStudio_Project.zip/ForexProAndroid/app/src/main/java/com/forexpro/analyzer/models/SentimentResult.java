package com.forexpro.analyzer.models;

import java.util.List;

public class SentimentResult {
    public String pair;
    public String sentiment;      // BULLISH / BEARISH / NEUTRAL
    public String signalBias;     // STRONG BUY / BUY / SELL / STRONG SELL / NEUTRAL
    public double bullishPct;
    public double bearishPct;
    public double neutralPct;
    public double confidence;
    public List<HeadlineScore> headlines;
    public String source;         // ONLINE / OFFLINE
    public long timestamp;

    public SentimentResult(String pair, String sentiment, String signalBias,
                           double bullishPct, double bearishPct, double neutralPct,
                           double confidence, List<HeadlineScore> headlines,
                           String source, long timestamp) {
        this.pair        = pair;
        this.sentiment   = sentiment;
        this.signalBias  = signalBias;
        this.bullishPct  = bullishPct;
        this.bearishPct  = bearishPct;
        this.neutralPct  = neutralPct;
        this.confidence  = confidence;
        this.headlines   = headlines;
        this.source      = source;
        this.timestamp   = timestamp;
    }

    public static class HeadlineScore {
        public String headline;
        public double score;

        public HeadlineScore(String headline, double score) {
            this.headline = headline;
            this.score = score;
        }

        public String getSentimentLabel() {
            if (score > 0.5) return "🟢 BULLISH";
            if (score < -0.5) return "🔴 BEARISH";
            return "⚪ NEUTRAL";
        }
    }
}
