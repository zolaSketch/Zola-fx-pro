package com.forexpro.analyzer.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import com.forexpro.analyzer.R;
import java.util.*;

public class NewsFragment extends Fragment {

    private ListView lvNews;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle state) {
        View v = inflater.inflate(R.layout.fragment_news, container, false);
        lvNews = v.findViewById(R.id.lvNews);
        loadNews();
        return v;
    }

    private void loadNews() {
        List<String> newsItems = Arrays.asList(
            "🔴 HIGH | Fed Minutes: Rate cuts less likely in 2025 | USD ↑",
            "🔴 HIGH | ECB: Eurozone inflation falling faster than expected | EUR ↓",
            "🟡 MED  | UK GDP Q4 beats forecast at 0.3% growth | GBP ↑",
            "🔴 HIGH | BOJ signals exit from negative rates | JPY ↑↑",
            "🟡 MED  | US Non-Farm Payrolls: 187K vs 180K expected | USD ↑",
            "🟢 LOW  | Eurozone Manufacturing PMI: 46.1 (prev 45.8) | EUR →",
            "🔴 HIGH | China PMI misses, AUD under pressure | AUD ↓",
            "🔴 HIGH | Middle East tensions escalate, oil spikes | CAD ↑ JPY ↑",
            "🟡 MED  | RBNZ holds rates, NZD steady | NZD →",
            "🟡 MED  | SNB intervenes to cap CHF strength | CHF ↓",
            "🔴 HIGH | US CPI YoY: 3.1% vs 3.0% expected | USD ↑",
            "🟢 LOW  | Australian employment +30K, rate cut hopes fade | AUD ↑",
            "🔴 HIGH | Geopolitical risk: NATO-Russia tensions rise | JPY ↑ CHF ↑",
            "🟡 MED  | OPEC+ extends production cuts | CAD ↑ USD ↓",
            "🔴 HIGH | US Retail Sales miss: -0.2% | USD ↓"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_list_item_1, newsItems);
        lvNews.setAdapter(adapter);
    }
}
