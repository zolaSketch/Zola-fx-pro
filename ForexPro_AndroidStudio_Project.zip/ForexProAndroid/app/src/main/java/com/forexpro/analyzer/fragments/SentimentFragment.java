package com.forexpro.analyzer.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.adapters.HeadlineAdapter;
import com.forexpro.analyzer.models.SentimentResult;
import com.forexpro.analyzer.sentiment.SentimentAnalyzer;

public class SentimentFragment extends Fragment {

    private static final String[] PAIRS = {
        "EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD","NZD/USD"
    };

    private SentimentAnalyzer analyzer;
    private TextView tvSentiment, tvSignalBias, tvBullishPct, tvBearishPct;
    private TextView tvSource, tvConfidence, tvWarImpact;
    private ProgressBar progressSentiment;
    private ProgressBar pbBullish, pbBearish;
    private RecyclerView rvHeadlines;
    private Spinner spinnerPair;
    private EditText etNewsInput;
    private Button btnAnalyzeNews;
    private TextView tvWarResult;

    private HeadlineAdapter headlineAdapter;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sentiment, container, false);
        analyzer = new SentimentAnalyzer(requireContext());

        bindViews(view);
        setupRecycler();
        setupSpinner();
        setupWarAnalysis();

        analyzeCurrentPair("EUR/USD");
        return view;
    }

    private void bindViews(View v) {
        tvSentiment      = v.findViewById(R.id.tvSentiment);
        tvSignalBias     = v.findViewById(R.id.tvSignalBias);
        tvBullishPct     = v.findViewById(R.id.tvBullishPct);
        tvBearishPct     = v.findViewById(R.id.tvBearishPct);
        tvSource         = v.findViewById(R.id.tvSource);
        tvConfidence     = v.findViewById(R.id.tvConfidence);
        progressSentiment= v.findViewById(R.id.progressSentiment);
        pbBullish        = v.findViewById(R.id.pbBullish);
        pbBearish        = v.findViewById(R.id.pbBearish);
        rvHeadlines      = v.findViewById(R.id.rvHeadlines);
        spinnerPair      = v.findViewById(R.id.spinnerPairSentiment);
        etNewsInput      = v.findViewById(R.id.etNewsInput);
        btnAnalyzeNews   = v.findViewById(R.id.btnAnalyzeNews);
        tvWarResult      = v.findViewById(R.id.tvWarResult);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_spinner_item, PAIRS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPair.setAdapter(adapter);
        spinnerPair.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int i, long id) {
                analyzeCurrentPair(PAIRS[i]);
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    private void setupRecycler() {
        headlineAdapter = new HeadlineAdapter();
        rvHeadlines.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvHeadlines.setAdapter(headlineAdapter);
    }

    private void setupWarAnalysis() {
        btnAnalyzeNews.setOnClickListener(v -> {
            String newsText = etNewsInput.getText().toString().trim();
            if (newsText.isEmpty()) {
                etNewsInput.setError("Enter news text");
                return;
            }
            // Score the text
            double score = analyzer.scoreText(newsText);
            String sentiment = score > 0.5 ? "🟢 BULLISH" : score < -0.5 ? "🔴 BEARISH" : "⚪ NEUTRAL";
            String scoreStr  = String.format("Score: %.2f | %s", score, sentiment);

            // Geopolitical impact
            java.util.Map<String,String> impact = analyzer.analyzeGeopoliticalImpact(newsText);
            StringBuilder sb = new StringBuilder();
            sb.append("Sentiment: ").append(scoreStr).append("\n\n");
            sb.append("Currency Impact:\n");
            for (java.util.Map.Entry<String,String> entry : impact.entrySet()) {
                sb.append("  ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
            }
            tvWarResult.setText(sb.toString());
            tvWarResult.setVisibility(View.VISIBLE);
        });
    }

    private void analyzeCurrentPair(String pair) {
        showLoading(true);
        analyzer.analyze(pair, new SentimentAnalyzer.SentimentCallback() {
            @Override
            public void onResult(SentimentResult result) {
                mainHandler.post(() -> updateUI(result));
            }
            @Override
            public void onError(String error) {
                mainHandler.post(() -> showLoading(false));
            }
        });
    }

    private void updateUI(SentimentResult r) {
        tvSentiment.setText(r.sentiment);
        tvSignalBias.setText(r.signalBias);
        tvBullishPct.setText(String.format("%.0f%%", r.bullishPct));
        tvBearishPct.setText(String.format("%.0f%%", r.bearishPct));
        tvSource.setText("Source: " + r.source);
        tvConfidence.setText(String.format("Confidence: %.0f%%", r.confidence));

        pbBullish.setProgress((int) r.bullishPct);
        pbBearish.setProgress((int) r.bearishPct);

        // Color
        int color = "BULLISH".equals(r.sentiment) ? 0xFF00FF88
                  : "BEARISH".equals(r.sentiment) ? 0xFFFF3355
                  : 0xFFFF8C00;
        tvSentiment.setTextColor(color);
        tvSignalBias.setTextColor(color);

        // Headlines
        if (r.headlines != null) {
            headlineAdapter.setData(r.headlines);
        }
        showLoading(false);
    }

    private void showLoading(boolean show) {
        if (progressSentiment != null)
            progressSentiment.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (analyzer != null) analyzer.shutdown();
    }
}
