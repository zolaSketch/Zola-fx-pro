package com.forexpro.analyzer.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.engine.SignalEngine;
import com.forexpro.analyzer.models.ForexSignal;
import java.util.*;
import java.util.concurrent.*;

// ─── SCANNER FRAGMENT ─────────────────────────────────────────────
class ScannerData {
    String pair; String signal; double confidence; double entry;
    ScannerData(String p, String s, double c, double e) { pair=p; signal=s; confidence=c; entry=e; }
}

public class ScannerFragment extends Fragment {
    private static final String[] ALL_PAIRS = {
        "EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD",
        "NZD/USD","EUR/GBP","USD/CHF","EUR/JPY","GBP/JPY"
    };

    private ListView listView;
    private Button btnScan;
    private ProgressBar progressScan;
    private TextView tvScanStatus;
    private final ExecutorService exec = Executors.newFixedThreadPool(3);

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle state) {
        View v = inflater.inflate(R.layout.fragment_scanner, container, false);
        listView     = v.findViewById(R.id.listScanner);
        btnScan      = v.findViewById(R.id.btnScan);
        progressScan = v.findViewById(R.id.progressScan);
        tvScanStatus = v.findViewById(R.id.tvScanStatus);

        btnScan.setOnClickListener(x -> scanAll());
        scanAll(); // Auto-scan on open
        return v;
    }

    private void scanAll() {
        btnScan.setEnabled(false);
        progressScan.setVisibility(View.VISIBLE);
        tvScanStatus.setText("Scanning " + ALL_PAIRS.length + " pairs...");

        exec.execute(() -> {
            List<ScannerData> results = new ArrayList<>();
            for (String pair : ALL_PAIRS) {
                ForexSignal sig = SignalEngine.generateSignal(pair, "H1");
                results.add(new ScannerData(pair, sig.signal, sig.confidence, sig.entry));
            }
            // Sort by confidence desc
            results.sort((a, b) -> Double.compare(b.confidence, a.confidence));

            requireActivity().runOnUiThread(() -> {
                List<String> rows = new ArrayList<>();
                for (ScannerData d : results) {
                    boolean isJpy = d.pair.contains("JPY");
                    rows.add(String.format("%-10s │ %4s │ %3.0f%% │ %s",
                        d.pair, d.signal, d.confidence,
                        String.format(isJpy ? "%.3f" : "%.5f", d.entry)));
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    requireContext(), android.R.layout.simple_list_item_1, rows);
                listView.setAdapter(adapter);
                progressScan.setVisibility(View.GONE);
                btnScan.setEnabled(true);
                tvScanStatus.setText("✅ Scan complete — " + ALL_PAIRS.length + " pairs analyzed");
            });
        });
    }
}
