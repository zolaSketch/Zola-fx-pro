package com.forexpro.analyzer.adapters;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.models.SentimentResult;
import java.util.ArrayList;
import java.util.List;

public class HeadlineAdapter extends RecyclerView.Adapter<HeadlineAdapter.VH> {

    private List<SentimentResult.HeadlineScore> data = new ArrayList<>();

    public void setData(List<SentimentResult.HeadlineScore> newData) {
        data = newData;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_headline, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        SentimentResult.HeadlineScore item = data.get(position);
        holder.tvHeadline.setText(item.headline);
        holder.tvScore.setText(item.getSentimentLabel());
        int color = item.score > 0.5 ? 0xFF00FF88
                  : item.score < -0.5 ? 0xFFFF3355
                  : 0xFF888888;
        holder.tvScore.setTextColor(color);
    }

    @Override public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvHeadline, tvScore;
        VH(View v) {
            super(v);
            tvHeadline = v.findViewById(R.id.tvHeadline);
            tvScore    = v.findViewById(R.id.tvScore);
        }
    }
}
