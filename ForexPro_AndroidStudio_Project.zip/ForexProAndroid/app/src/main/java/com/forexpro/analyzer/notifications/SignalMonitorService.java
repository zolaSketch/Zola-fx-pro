package com.forexpro.analyzer.notifications;

import android.app.*;
import android.content.Intent;
import android.os.*;
import androidx.core.app.NotificationCompat;
import com.forexpro.analyzer.ForexProApp;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.activities.MainActivity;
import com.forexpro.analyzer.engine.SignalEngine;
import com.forexpro.analyzer.models.ForexSignal;

/**
 * Background service that monitors signals and sends push notifications
 * when high-confidence BUY or SELL signals are detected
 */
public class SignalMonitorService extends Service {

    private static final String[] MONITORED_PAIRS = {"EUR/USD","GBP/USD","USD/JPY"};
    private static final double MIN_CONFIDENCE_TO_NOTIFY = 80.0;
    private static final long CHECK_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

    private Handler handler;
    private Runnable monitorRunnable;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        startForeground(1, buildForegroundNotification());
        startMonitoring();
    }

    private void startMonitoring() {
        monitorRunnable = () -> {
            new Thread(() -> {
                for (String pair : MONITORED_PAIRS) {
                    ForexSignal signal = SignalEngine.generateSignal(pair, "H1");
                    if (signal.confidence >= MIN_CONFIDENCE_TO_NOTIFY && !signal.isHold()) {
                        sendSignalNotification(signal);
                    }
                }
            }).start();
            handler.postDelayed(monitorRunnable, CHECK_INTERVAL_MS);
        };
        handler.postDelayed(monitorRunnable, 30_000); // First check after 30s
    }

    private void sendSignalNotification(ForexSignal signal) {
        boolean isJpy = signal.pair.contains("JPY");
        String fmt = isJpy ? "%.3f" : "%.5f";

        String title = signal.getSignalEmoji() + " " + signal.signal
                     + " Signal — " + signal.pair;
        String body  = String.format(
            "Entry: " + fmt + " | TP: " + fmt + " | SL: " + fmt + " | %.0f%% confidence",
            signal.entry, signal.takeProfit, signal.stopLoss, signal.confidence);

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int color = signal.isBuy() ? 0xFF00FF88 : 0xFFFF3355;

        Notification notification = new NotificationCompat.Builder(this, ForexProApp.CHANNEL_SIGNALS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setColor(color)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setVibrate(new long[]{0, 300, 200, 300})
            .build();

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify((int) System.currentTimeMillis(), notification);
    }

    private Notification buildForegroundNotification() {
        return new NotificationCompat.Builder(this, ForexProApp.CHANNEL_SIGNALS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("ForexPro Analyzer")
            .setContentText("Monitoring markets for signals...")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && monitorRunnable != null) {
            handler.removeCallbacks(monitorRunnable);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
