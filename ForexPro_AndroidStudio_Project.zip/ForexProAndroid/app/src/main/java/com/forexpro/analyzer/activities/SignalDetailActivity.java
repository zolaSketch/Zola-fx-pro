package com.forexpro.analyzer.activities;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.forexpro.analyzer.R;
public class SignalDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signal_detail);
    }
}
