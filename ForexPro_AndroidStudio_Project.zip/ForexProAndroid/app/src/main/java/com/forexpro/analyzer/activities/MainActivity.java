package com.forexpro.analyzer.activities;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.fragments.*;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;

    // Fragments
    private SignalsFragment   signalsFragment;
    private ScannerFragment   scannerFragment;
    private SentimentFragment sentimentFragment;
    private RiskFragment      riskFragment;
    private NewsFragment      newsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initFragments();
        setupBottomNav();

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(signalsFragment);
        }
    }

    private void initFragments() {
        signalsFragment   = new SignalsFragment();
        scannerFragment   = new ScannerFragment();
        sentimentFragment = new SentimentFragment();
        riskFragment      = new RiskFragment();
        newsFragment      = new NewsFragment();
    }

    private void setupBottomNav() {
        bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_signals)   { loadFragment(signalsFragment);   return true; }
            if (id == R.id.nav_scanner)   { loadFragment(scannerFragment);   return true; }
            if (id == R.id.nav_sentiment) { loadFragment(sentimentFragment); return true; }
            if (id == R.id.nav_risk)      { loadFragment(riskFragment);      return true; }
            if (id == R.id.nav_news)      { loadFragment(newsFragment);      return true; }
            return false;
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit();
    }
}
