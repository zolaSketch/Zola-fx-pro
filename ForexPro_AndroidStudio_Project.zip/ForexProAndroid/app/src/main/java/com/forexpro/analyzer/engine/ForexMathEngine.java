package com.forexpro.analyzer.engine;

/**
 * ForexMathEngine.java
 *
 * ሁሉም የፎሬክስ ሂሳብ ቀመሮች - Complete Forex Mathematics Library
 *
 * ያካትታል:
 *  - Calculus (Derivatives, Integrals, Limits)
 *  - Slope & Rate of Change
 *  - Technical Indicators (RSI, MACD, EMA, SMA, Bollinger, ATR, ADX, Stochastic, CCI, Williams %R, Ichimoku)
 *  - Fibonacci (Retracement, Extension, Fan, Arc)
 *  - Elliott Wave Analysis
 *  - Pivot Points (Classic, Camarilla, Woodie, DeMark)
 *  - Risk & Money Management
 *  - Statistical Analysis (Standard Deviation, Variance, Correlation, Regression)
 *  - Options Pricing (Black-Scholes)
 *  - Volatility (Historical, Implied)
 *  - Support & Resistance Detection
 *  - Trend Analysis
 */
public class ForexMathEngine {

    // ════════════════════════════════════════════════════════════════
    // 1. CALCULUS - ካልኩለስ
    // ════════════════════════════════════════════════════════════════

    /**
     * Numerical Derivative (First Order) - የፈጣን ለውጥ መጠን
     * f'(x) ≈ [f(x+h) - f(x-h)] / 2h
     * Used to find: Rate of price change, momentum
     */
    public static double derivative(double[] prices, int index) {
        if (index <= 0 || index >= prices.length - 1) return 0;
        double h = 1.0;
        return (prices[index + 1] - prices[index - 1]) / (2 * h);
    }

    /**
     * Second Derivative - ሁለተኛ ደረጃ ዴሪቬቲቭ
     * f''(x) ≈ [f(x+h) - 2f(x) + f(x-h)] / h²
     * Used to find: Acceleration/deceleration of price, trend reversal points
     */
    public static double secondDerivative(double[] prices, int index) {
        if (index <= 0 || index >= prices.length - 1) return 0;
        return prices[index + 1] - 2 * prices[index] + prices[index - 1];
    }

    /**
     * Partial Derivative for multi-variable price modeling
     * Used in Black-Scholes options Greeks
     */
    public static double partialDerivative(double[] x, double[] y, int index) {
        if (index <= 0 || index >= x.length - 1) return 0;
        return (y[index + 1] - y[index - 1]) / (x[index + 1] - x[index - 1]);
    }

    /**
     * Numerical Integration (Trapezoidal Rule) - ቦታ ስሌት
     * ∫f(x)dx ≈ Σ [f(xᵢ) + f(xᵢ₊₁)] * h / 2
     * Used to find: Area under price curve, cumulative momentum
     */
    public static double integrate(double[] prices, int start, int end) {
        if (start >= end || end >= prices.length) return 0;
        double area = 0;
        for (int i = start; i < end; i++) {
            area += (prices[i] + prices[i + 1]) / 2.0;
        }
        return area;
    }

    /**
     * Limit approximation - ወሰን ስሌት
     * lim(h→0) [f(x+h) - f(x)] / h
     */
    public static double limit(double[] prices, int index) {
        if (index >= prices.length - 1) return 0;
        double h = 0.0001;
        return (prices[Math.min(index + 1, prices.length - 1)] - prices[index]) / h;
    }

    // ════════════════════════════════════════════════════════════════
    // 2. SLOPE & LINEAR REGRESSION - ስሎፕ
    // ════════════════════════════════════════════════════════════════

    /**
     * Price Slope - የዋጋ ቁልቁለት/ቁልቁለት
     * slope = (y₂ - y₁) / (x₂ - x₁)
     */
    public static double slope(double[] prices, int period) {
        if (prices.length < period) return 0;
        int n = prices.length;
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        int start = n - period;
        for (int i = 0; i < period; i++) {
            double x = i;
            double y = prices[start + i];
            sumX  += x;
            sumY  += y;
            sumXY += x * y;
            sumX2 += x * x;
        }
        double denom = period * sumX2 - sumX * sumX;
        if (denom == 0) return 0;
        return (period * sumXY - sumX * sumY) / denom;
    }

    /**
     * Linear Regression Line - መስመር ምጣኔ
     * Returns [slope, intercept]
     */
    public static double[] linearRegression(double[] prices) {
        int n = prices.length;
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        for (int i = 0; i < n; i++) {
            sumX  += i;
            sumY  += prices[i];
            sumXY += i * prices[i];
            sumX2 += (double) i * i;
        }
        double denom = n * sumX2 - sumX * sumX;
        if (denom == 0) return new double[]{0, sumY / n};
        double m = (n * sumXY - sumX * sumY) / denom;
        double b = (sumY - m * sumX) / n;
        return new double[]{m, b};
    }

    /**
     * R-Squared (Coefficient of Determination) - የትክክለኝነት መለኪያ
     * R² = 1 - (SS_res / SS_tot)
     */
    public static double rSquared(double[] prices) {
        double[] reg = linearRegression(prices);
        double slope = reg[0], intercept = reg[1];
        int n = prices.length;
        double meanY = 0;
        for (double p : prices) meanY += p;
        meanY /= n;

        double ssTot = 0, ssRes = 0;
        for (int i = 0; i < n; i++) {
            double predicted = slope * i + intercept;
            ssTot += Math.pow(prices[i] - meanY, 2);
            ssRes += Math.pow(prices[i] - predicted, 2);
        }
        return ssTot == 0 ? 1 : 1 - (ssRes / ssTot);
    }

    /**
     * Angle of Trend - የትረንድ አንግል (degrees)
     */
    public static double trendAngle(double[] prices, int period) {
        double s = slope(prices, period);
        return Math.toDegrees(Math.atan(s));
    }

    // ════════════════════════════════════════════════════════════════
    // 3. MOVING AVERAGES - ተንቀሳቃሽ አማካይ
    // ════════════════════════════════════════════════════════════════

    /** Simple Moving Average - ቀላል አማካይ */
    public static double sma(double[] prices, int period) {
        if (prices.length < period) return 0;
        double sum = 0;
        for (int i = prices.length - period; i < prices.length; i++) {
            sum += prices[i];
        }
        return sum / period;
    }

    /** Exponential Moving Average - ኤክስፖነንሻል አማካይ */
    public static double[] ema(double[] prices, int period) {
        double[] result = new double[prices.length];
        double multiplier = 2.0 / (period + 1);
        result[0] = prices[0];
        for (int i = 1; i < prices.length; i++) {
            result[i] = (prices[i] - result[i - 1]) * multiplier + result[i - 1];
        }
        return result;
    }

    /** Weighted Moving Average */
    public static double wma(double[] prices, int period) {
        if (prices.length < period) return 0;
        double weightedSum = 0, weightSum = 0;
        int start = prices.length - period;
        for (int i = 0; i < period; i++) {
            int weight = i + 1;
            weightedSum += prices[start + i] * weight;
            weightSum   += weight;
        }
        return weightedSum / weightSum;
    }

    /** Hull Moving Average - HMA = WMA(2*WMA(n/2) − WMA(n)), sqrt(n)) */
    public static double hma(double[] prices, int period) {
        int halfPeriod = period / 2;
        int sqrtPeriod = (int) Math.sqrt(period);
        double wmaHalf = wma(prices, halfPeriod);
        double wmaFull = wma(prices, period);
        double raw = 2 * wmaHalf - wmaFull;
        // Simplified HMA
        return raw;
    }

    // ════════════════════════════════════════════════════════════════
    // 4. RSI - Relative Strength Index
    // ════════════════════════════════════════════════════════════════

    /**
     * RSI = 100 - [100 / (1 + RS)]
     * RS = Average Gain / Average Loss
     */
    public static double rsi(double[] prices, int period) {
        if (prices.length < period + 1) return 50;
        double avgGain = 0, avgLoss = 0;

        for (int i = 1; i <= period; i++) {
            double change = prices[prices.length - period - 1 + i]
                          - prices[prices.length - period - 2 + i];
            if (change > 0) avgGain += change;
            else avgLoss += Math.abs(change);
        }
        avgGain /= period;
        avgLoss /= period;

        if (avgLoss == 0) return 100;
        double rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }

    /** Stochastic RSI */
    public static double stochasticRSI(double[] prices, int period) {
        if (prices.length < period * 2) return 50;
        double[] rsiValues = new double[period];
        for (int i = 0; i < period; i++) {
            double[] sub = java.util.Arrays.copyOfRange(prices, i, i + period + 1);
            rsiValues[i] = rsi(sub, period);
        }
        double minRSI = rsiValues[0], maxRSI = rsiValues[0];
        for (double r : rsiValues) {
            if (r < minRSI) minRSI = r;
            if (r > maxRSI) maxRSI = r;
        }
        double range = maxRSI - minRSI;
        if (range == 0) return 50;
        return (rsiValues[period - 1] - minRSI) / range * 100;
    }

    // ════════════════════════════════════════════════════════════════
    // 5. MACD - Moving Average Convergence Divergence
    // ════════════════════════════════════════════════════════════════

    /**
     * MACD Line = EMA(12) - EMA(26)
     * Signal Line = EMA(9) of MACD
     * Histogram = MACD - Signal
     */
    public static double[] macd(double[] prices) {
        double[] ema12 = ema(prices, 12);
        double[] ema26 = ema(prices, 26);

        double macdLine = ema12[prices.length - 1] - ema26[prices.length - 1];

        // Signal: EMA(9) of last 9 MACD values
        double[] macdHistory = new double[9];
        for (int i = 0; i < 9; i++) {
            int idx = prices.length - 9 + i;
            if (idx >= 0 && idx < prices.length) {
                macdHistory[i] = ema12[idx] - ema26[idx];
            }
        }
        double[] signalArr = ema(macdHistory, 9);
        double signal = signalArr[8];
        double histogram = macdLine - signal;

        return new double[]{macdLine, signal, histogram};
    }

    // ════════════════════════════════════════════════════════════════
    // 6. BOLLINGER BANDS
    // ════════════════════════════════════════════════════════════════

    /**
     * Upper Band = SMA + (2 × StdDev)
     * Lower Band = SMA - (2 × StdDev)
     * Returns [upper, middle, lower, bandwidth, %B]
     */
    public static double[] bollingerBands(double[] prices, int period, double multiplier) {
        double middle = sma(prices, period);
        double stdDev = standardDeviation(prices, period);
        double upper = middle + multiplier * stdDev;
        double lower = middle - multiplier * stdDev;
        double bandwidth = (upper - lower) / middle * 100;
        double currentPrice = prices[prices.length - 1];
        double percentB = (upper - lower) == 0 ? 0.5
                        : (currentPrice - lower) / (upper - lower);
        return new double[]{upper, middle, lower, bandwidth, percentB};
    }

    // ════════════════════════════════════════════════════════════════
    // 7. ATR - Average True Range - VariableRange
    // ════════════════════════════════════════════════════════════════

    /**
     * True Range = max(High-Low, |High-PrevClose|, |Low-PrevClose|)
     * ATR = SMA(TR, period)
     */
    public static double atr(double[] highs, double[] lows, double[] closes, int period) {
        int n = closes.length;
        if (n < period + 1) return 0;
        double[] tr = new double[n - 1];
        for (int i = 1; i < n; i++) {
            double hl   = highs[i] - lows[i];
            double hpc  = Math.abs(highs[i] - closes[i - 1]);
            double lpc  = Math.abs(lows[i] - closes[i - 1]);
            tr[i - 1]   = Math.max(hl, Math.max(hpc, lpc));
        }
        double sum = 0;
        for (int i = tr.length - period; i < tr.length; i++) sum += tr[i];
        return sum / period;
    }

    // ════════════════════════════════════════════════════════════════
    // 8. ADX - Average Directional Index - ትረንድ ጥንካሬ
    // ════════════════════════════════════════════════════════════════

    /**
     * Returns [ADX, +DI, -DI]
     * ADX > 25: Strong trend
     * ADX < 20: Weak / ranging
     */
    public static double[] adx(double[] highs, double[] lows, double[] closes, int period) {
        int n = closes.length;
        if (n < period + 1) return new double[]{0, 0, 0};

        double[] plusDM  = new double[n - 1];
        double[] minusDM = new double[n - 1];
        double[] tr      = new double[n - 1];

        for (int i = 1; i < n; i++) {
            double upMove   = highs[i] - highs[i - 1];
            double downMove = lows[i - 1] - lows[i];
            plusDM[i-1]  = (upMove > downMove && upMove > 0) ? upMove : 0;
            minusDM[i-1] = (downMove > upMove && downMove > 0) ? downMove : 0;

            double hl  = highs[i] - lows[i];
            double hpc = Math.abs(highs[i] - closes[i-1]);
            double lpc = Math.abs(lows[i] - closes[i-1]);
            tr[i-1] = Math.max(hl, Math.max(hpc, lpc));
        }

        double smTR = 0, smPlusDM = 0, smMinusDM = 0;
        for (int i = 0; i < period; i++) {
            smTR      += tr[i];
            smPlusDM  += plusDM[i];
            smMinusDM += minusDM[i];
        }

        double plusDI  = smTR == 0 ? 0 : (smPlusDM / smTR) * 100;
        double minusDI = smTR == 0 ? 0 : (smMinusDM / smTR) * 100;
        double dx = (plusDI + minusDI) == 0 ? 0
                  : Math.abs(plusDI - minusDI) / (plusDI + minusDI) * 100;

        // Simplified ADX (real needs smoothed DX over period)
        return new double[]{dx, plusDI, minusDI};
    }

    // ════════════════════════════════════════════════════════════════
    // 9. STOCHASTIC OSCILLATOR
    // ════════════════════════════════════════════════════════════════

    /**
     * %K = (Current Close - Lowest Low) / (Highest High - Lowest Low) × 100
     * %D = SMA(%K, 3)
     */
    public static double[] stochastic(double[] highs, double[] lows, double[] closes, int period) {
        int n = closes.length;
        if (n < period) return new double[]{50, 50};

        double lowestLow   = lows[n - period];
        double highestHigh = highs[n - period];
        for (int i = n - period; i < n; i++) {
            if (lows[i]  < lowestLow)   lowestLow   = lows[i];
            if (highs[i] > highestHigh) highestHigh = highs[i];
        }

        double range = highestHigh - lowestLow;
        double kPct  = range == 0 ? 50 : (closes[n-1] - lowestLow) / range * 100;

        // %D = simple average of last 3 %K values
        double dPct = kPct; // simplified
        return new double[]{kPct, dPct};
    }

    // ════════════════════════════════════════════════════════════════
    // 10. CCI - Commodity Channel Index
    // ════════════════════════════════════════════════════════════════

    /**
     * CCI = (Typical Price - SMA) / (0.015 × Mean Deviation)
     * Typical Price = (High + Low + Close) / 3
     */
    public static double cci(double[] highs, double[] lows, double[] closes, int period) {
        int n = closes.length;
        if (n < period) return 0;

        double[] tp = new double[period];
        for (int i = 0; i < period; i++) {
            tp[i] = (highs[n-period+i] + lows[n-period+i] + closes[n-period+i]) / 3.0;
        }

        double smaTP = 0;
        for (double t : tp) smaTP += t;
        smaTP /= period;

        double meanDev = 0;
        for (double t : tp) meanDev += Math.abs(t - smaTP);
        meanDev /= period;

        return meanDev == 0 ? 0 : (tp[period-1] - smaTP) / (0.015 * meanDev);
    }

    // ════════════════════════════════════════════════════════════════
    // 11. WILLIAMS %R
    // ════════════════════════════════════════════════════════════════

    public static double williamsR(double[] highs, double[] lows, double[] closes, int period) {
        int n = closes.length;
        if (n < period) return -50;

        double hh = highs[n-period], ll = lows[n-period];
        for (int i = n-period; i < n; i++) {
            if (highs[i] > hh) hh = highs[i];
            if (lows[i]  < ll) ll = lows[i];
        }
        return hh == ll ? -50 : ((hh - closes[n-1]) / (hh - ll)) * -100;
    }

    // ════════════════════════════════════════════════════════════════
    // 12. FIBONACCI LEVELS - ፊቦናቺ ደረጃዎች
    // ════════════════════════════════════════════════════════════════

    /**
     * Fibonacci Retracement Levels
     * Returns price levels: [0%, 23.6%, 38.2%, 50%, 61.8%, 76.4%, 100%]
     */
    public static double[] fibonacciRetracement(double high, double low) {
        double diff = high - low;
        return new double[]{
            high,                        // 0%
            high - diff * 0.236,         // 23.6%
            high - diff * 0.382,         // 38.2%
            high - diff * 0.500,         // 50%
            high - diff * 0.618,         // 61.8%
            high - diff * 0.764,         // 76.4%
            low                          // 100%
        };
    }

    /**
     * Fibonacci Extension Levels
     * Used for Take Profit targets
     * Returns [127.2%, 161.8%, 200%, 261.8%]
     */
    public static double[] fibonacciExtension(double high, double low, double retraceEnd) {
        double diff = high - low;
        return new double[]{
            retraceEnd + diff * 1.272,
            retraceEnd + diff * 1.618,
            retraceEnd + diff * 2.000,
            retraceEnd + diff * 2.618
        };
    }

    /**
     * Golden Ratio - ወርቃማ ምጣኔ
     */
    public static final double PHI = 1.6180339887;

    // ════════════════════════════════════════════════════════════════
    // 13. PIVOT POINTS - ፒቮት ነጥቦች
    // ════════════════════════════════════════════════════════════════

    /**
     * Classic Pivot Points
     * Returns [PP, R1, R2, R3, S1, S2, S3]
     */
    public static double[] classicPivot(double high, double low, double close) {
        double pp = (high + low + close) / 3.0;
        double r1 = 2 * pp - low;
        double s1 = 2 * pp - high;
        double r2 = pp + (high - low);
        double s2 = pp - (high - low);
        double r3 = high + 2 * (pp - low);
        double s3 = low - 2 * (high - pp);
        return new double[]{pp, r1, r2, r3, s1, s2, s3};
    }

    /**
     * Camarilla Pivot Points
     * Returns [PP, R1, R2, R3, R4, S1, S2, S3, S4]
     */
    public static double[] camarillaPivot(double high, double low, double close) {
        double range = high - low;
        double pp = (high + low + close) / 3.0;
        double r1 = close + range * 1.0833;
        double r2 = close + range * 1.1666;
        double r3 = close + range * 1.2500;
        double r4 = close + range * 1.5000;
        double s1 = close - range * 1.0833;
        double s2 = close - range * 1.1666;
        double s3 = close - range * 1.2500;
        double s4 = close - range * 1.5000;
        return new double[]{pp, r1, r2, r3, r4, s1, s2, s3, s4};
    }

    /**
     * Woodie Pivot Points
     */
    public static double[] woodiePivot(double high, double low, double close) {
        double pp = (high + low + 2 * close) / 4.0;
        double r1 = 2 * pp - low;
        double r2 = pp + high - low;
        double s1 = 2 * pp - high;
        double s2 = pp - high + low;
        return new double[]{pp, r1, r2, s1, s2};
    }

    // ════════════════════════════════════════════════════════════════
    // 14. ICHIMOKU CLOUD - ኢቺሞኩ
    // ════════════════════════════════════════════════════════════════

    /**
     * Ichimoku Kinko Hyo Components
     * Returns [Tenkan-sen, Kijun-sen, Senkou A, Senkou B, Chikou]
     */
    public static double[] ichimoku(double[] highs, double[] lows, double[] closes) {
        int n = closes.length;
        if (n < 52) return new double[]{0, 0, 0, 0, 0};

        // Tenkan-sen (Conversion Line) = (9-period high + 9-period low) / 2
        double tenkanHigh = highs[n-9], tenkanLow = lows[n-9];
        for (int i = n-9; i < n; i++) {
            if (highs[i] > tenkanHigh) tenkanHigh = highs[i];
            if (lows[i]  < tenkanLow)  tenkanLow  = lows[i];
        }
        double tenkan = (tenkanHigh + tenkanLow) / 2.0;

        // Kijun-sen (Base Line) = (26-period high + 26-period low) / 2
        double kijunHigh = highs[n-26], kijunLow = lows[n-26];
        for (int i = n-26; i < n; i++) {
            if (highs[i] > kijunHigh) kijunHigh = highs[i];
            if (lows[i]  < kijunLow)  kijunLow  = lows[i];
        }
        double kijun = (kijunHigh + kijunLow) / 2.0;

        // Senkou Span A = (Tenkan + Kijun) / 2
        double senkouA = (tenkan + kijun) / 2.0;

        // Senkou Span B = (52-period high + 52-period low) / 2
        double sbHigh = highs[n-52], sbLow = lows[n-52];
        for (int i = n-52; i < n; i++) {
            if (highs[i] > sbHigh) sbHigh = highs[i];
            if (lows[i]  < sbLow)  sbLow  = lows[i];
        }
        double senkouB = (sbHigh + sbLow) / 2.0;

        // Chikou Span = Current close (26 periods ago)
        double chikou = closes[n - 26];

        return new double[]{tenkan, kijun, senkouA, senkouB, chikou};
    }

    // ════════════════════════════════════════════════════════════════
    // 15. STATISTICS - ስታቲስቲክስ
    // ════════════════════════════════════════════════════════════════

    public static double mean(double[] data) {
        double sum = 0;
        for (double d : data) sum += d;
        return sum / data.length;
    }

    public static double variance(double[] data) {
        double m = mean(data);
        double sum = 0;
        for (double d : data) sum += Math.pow(d - m, 2);
        return sum / data.length;
    }

    public static double standardDeviation(double[] data, int period) {
        if (data.length < period) return 0;
        double[] sub = java.util.Arrays.copyOfRange(data, data.length - period, data.length);
        return Math.sqrt(variance(sub));
    }

    /**
     * Pearson Correlation Coefficient
     * r = Σ[(x-x̄)(y-ȳ)] / √[Σ(x-x̄)² × Σ(y-ȳ)²]
     */
    public static double correlation(double[] x, double[] y) {
        int n = Math.min(x.length, y.length);
        double mx = mean(x), my = mean(y);
        double num = 0, dx = 0, dy = 0;
        for (int i = 0; i < n; i++) {
            num += (x[i] - mx) * (y[i] - my);
            dx  += Math.pow(x[i] - mx, 2);
            dy  += Math.pow(y[i] - my, 2);
        }
        return (dx == 0 || dy == 0) ? 0 : num / Math.sqrt(dx * dy);
    }

    /**
     * Z-Score - ከሚጠበቀው ምን ያህል ራቀ
     */
    public static double zScore(double value, double[] data) {
        double m  = mean(data);
        double sd = Math.sqrt(variance(data));
        return sd == 0 ? 0 : (value - m) / sd;
    }

    // ════════════════════════════════════════════════════════════════
    // 16. VOLATILITY - ተለዋዋጭነት
    // ════════════════════════════════════════════════════════════════

    /**
     * Historical Volatility (Annualized)
     * σ_annual = σ_daily × √252
     */
    public static double historicalVolatility(double[] prices, int period) {
        if (prices.length < period + 1) return 0;
        double[] returns = new double[period];
        int n = prices.length;
        for (int i = 0; i < period; i++) {
            int idx = n - period + i;
            returns[i] = Math.log(prices[idx] / prices[idx - 1]);
        }
        double stdDev = Math.sqrt(variance(returns));
        return stdDev * Math.sqrt(252) * 100; // annualized %
    }

    // ════════════════════════════════════════════════════════════════
    // 17. BLACK-SCHOLES (Options Pricing)
    // ════════════════════════════════════════════════════════════════

    /**
     * Black-Scholes Call Option Price
     * C = S*N(d1) - K*e^(-rT)*N(d2)
     * d1 = [ln(S/K) + (r + σ²/2)T] / (σ√T)
     * d2 = d1 - σ√T
     */
    public static double blackScholesCall(double S, double K, double r, double T, double sigma) {
        double d1 = (Math.log(S / K) + (r + sigma * sigma / 2) * T) / (sigma * Math.sqrt(T));
        double d2 = d1 - sigma * Math.sqrt(T);
        return S * normalCDF(d1) - K * Math.exp(-r * T) * normalCDF(d2);
    }

    public static double blackScholesPut(double S, double K, double r, double T, double sigma) {
        double d1 = (Math.log(S / K) + (r + sigma * sigma / 2) * T) / (sigma * Math.sqrt(T));
        double d2 = d1 - sigma * Math.sqrt(T);
        return K * Math.exp(-r * T) * normalCDF(-d2) - S * normalCDF(-d1);
    }

    /** Normal CDF approximation */
    public static double normalCDF(double x) {
        return 0.5 * (1 + erf(x / Math.sqrt(2)));
    }

    /** Error function approximation */
    private static double erf(double x) {
        double t = 1.0 / (1.0 + 0.3275911 * Math.abs(x));
        double y = 1.0 - (((((1.061405429 * t - 1.453152027) * t)
                + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
        return x >= 0 ? y : -y;
    }

    // ════════════════════════════════════════════════════════════════
    // 18. RISK MANAGEMENT - ሪስክ አስተዳደር
    // ════════════════════════════════════════════════════════════════

    /**
     * Position Size Calculator
     * Lot Size = (Account × Risk%) / (SL pips × Pip Value)
     */
    public static double positionSize(double accountBalance, double riskPercent,
                                       double slPips, double pipValue) {
        double riskAmount = accountBalance * (riskPercent / 100.0);
        return riskAmount / (slPips * pipValue);
    }

    /**
     * Risk/Reward Ratio
     */
    public static double riskRewardRatio(double entry, double tp, double sl) {
        double reward = Math.abs(tp - entry);
        double risk   = Math.abs(entry - sl);
        return risk == 0 ? 0 : reward / risk;
    }

    /**
     * Expected Value of a Trade
     * EV = (Win Rate × Avg Win) - (Loss Rate × Avg Loss)
     */
    public static double expectedValue(double winRate, double avgWin, double avgLoss) {
        return (winRate * avgWin) - ((1 - winRate) * avgLoss);
    }

    /**
     * Kelly Criterion - optimal position sizing
     * f* = (bp - q) / b
     * b = odds, p = win probability, q = loss probability
     */
    public static double kellyCriterion(double winRate, double riskReward) {
        double lossRate = 1 - winRate;
        return (winRate * riskReward - lossRate) / riskReward;
    }

    /**
     * Maximum Drawdown
     */
    public static double maxDrawdown(double[] equityCurve) {
        double peak = equityCurve[0];
        double maxDD = 0;
        for (double e : equityCurve) {
            if (e > peak) peak = e;
            double dd = (peak - e) / peak;
            if (dd > maxDD) maxDD = dd;
        }
        return maxDD * 100;
    }

    /**
     * Sharpe Ratio
     * Sharpe = (Return - RiskFreeRate) / StdDev
     */
    public static double sharpeRatio(double[] returns, double riskFreeRate) {
        double avgReturn = mean(returns);
        double stdDev = Math.sqrt(variance(returns));
        return stdDev == 0 ? 0 : (avgReturn - riskFreeRate / 252) / stdDev * Math.sqrt(252);
    }

    // ════════════════════════════════════════════════════════════════
    // 19. SUPPORT & RESISTANCE DETECTION
    // ════════════════════════════════════════════════════════════════

    /**
     * Find local maxima (resistance levels)
     */
    public static java.util.List<Double> findResistance(double[] highs, int lookback) {
        java.util.List<Double> levels = new java.util.ArrayList<>();
        for (int i = lookback; i < highs.length - lookback; i++) {
            boolean isPeak = true;
            for (int j = i - lookback; j <= i + lookback; j++) {
                if (j != i && highs[j] >= highs[i]) { isPeak = false; break; }
            }
            if (isPeak) levels.add(highs[i]);
        }
        return levels;
    }

    /**
     * Find local minima (support levels)
     */
    public static java.util.List<Double> findSupport(double[] lows, int lookback) {
        java.util.List<Double> levels = new java.util.ArrayList<>();
        for (int i = lookback; i < lows.length - lookback; i++) {
            boolean isValley = true;
            for (int j = i - lookback; j <= i + lookback; j++) {
                if (j != i && lows[j] <= lows[i]) { isValley = false; break; }
            }
            if (isValley) levels.add(lows[i]);
        }
        return levels;
    }

    // ════════════════════════════════════════════════════════════════
    // 20. COMPOUND SIGNAL SCORE - ሙሉ ትንተና ውጤት
    // ════════════════════════════════════════════════════════════════

    /**
     * Generates final BUY/SELL/HOLD signal with confidence score
     * Combines all indicators using weighted scoring
     * Returns [signal_direction, confidence_0_to_100]
     * signal: 1=BUY, -1=SELL, 0=HOLD
     */
    public static double[] compoundSignal(double[] closes, double[] highs,
                                           double[] lows, int period) {
        double score = 0;
        double maxScore = 0;

        // RSI (weight: 2)
        double rsiVal = rsi(closes, 14);
        if (rsiVal < 30)      { score += 2; }   // Oversold → BUY
        else if (rsiVal > 70) { score -= 2; }   // Overbought → SELL
        else if (rsiVal > 55) { score += 1; }
        else if (rsiVal < 45) { score -= 1; }
        maxScore += 2;

        // MACD (weight: 2)
        double[] macdVals = macd(closes);
        if (macdVals[2] > 0) score += 2;   // histogram positive
        else                 score -= 2;
        maxScore += 2;

        // EMA cross 20/50 (weight: 2)
        double[] ema20 = ema(closes, 20);
        double[] ema50 = ema(closes, 50);
        int n = closes.length - 1;
        if (n >= 0 && ema20[n] > ema50[n]) score += 2;
        else                               score -= 2;
        maxScore += 2;

        // Price vs EMA200 (weight: 1)
        if (closes.length >= 200) {
            double[] ema200 = ema(closes, 200);
            if (closes[n] > ema200[n]) score += 1;
            else                       score -= 1;
            maxScore += 1;
        }

        // Bollinger %B (weight: 1)
        double[] bb = bollingerBands(closes, 20, 2.0);
        if (bb[4] < 0.2)      score += 1;  // Near lower band → BUY
        else if (bb[4] > 0.8) score -= 1;  // Near upper band → SELL
        maxScore += 1;

        // Stochastic (weight: 2)
        double[] stoch = stochastic(highs, lows, closes, 14);
        if (stoch[0] < 20)      score += 2;
        else if (stoch[0] > 80) score -= 2;
        maxScore += 2;

        // ADX trend (weight: 1)
        double[] adxVals = adx(highs, lows, closes, 14);
        if (adxVals[0] > 25) {
            if (adxVals[1] > adxVals[2]) score += 1;
            else                         score -= 1;
        }
        maxScore += 1;

        // Slope direction (weight: 1)
        double slopeVal = slope(closes, period);
        if (slopeVal > 0) score += 1;
        else              score -= 1;
        maxScore += 1;

        // Confidence
        double confidence = 50 + (score / maxScore) * 50;
        confidence = Math.max(30, Math.min(95, confidence));

        int direction = score > 2 ? 1 : (score < -2 ? -1 : 0);
        return new double[]{direction, confidence};
    }
}
