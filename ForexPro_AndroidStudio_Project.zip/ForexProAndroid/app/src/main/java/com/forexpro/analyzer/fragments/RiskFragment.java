package com.forexpro.analyzer.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import com.forexpro.analyzer.R;
import com.forexpro.analyzer.engine.ForexMathEngine;

public class RiskFragment extends Fragment {

    private EditText etBalance, etRisk, etSl, etTp, etEntry;
    private Spinner  spinnerPair;
    private Button   btnCalculate;
    private TextView tvRiskAmount, tvLotSize, tvUnits, tvPipValue,
                     tvRrr, tvEv, tvKelly, tvSharpe;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle state) {
        View v = inflater.inflate(R.layout.fragment_risk, container, false);

        etBalance    = v.findViewById(R.id.etBalance);
        etRisk       = v.findViewById(R.id.etRiskPct);
        etSl         = v.findViewById(R.id.etSlPips);
        etTp         = v.findViewById(R.id.etTpPips);
        etEntry      = v.findViewById(R.id.etEntry);
        spinnerPair  = v.findViewById(R.id.spinnerPairRisk);
        btnCalculate = v.findViewById(R.id.btnCalculate);
        tvRiskAmount = v.findViewById(R.id.tvRiskAmount);
        tvLotSize    = v.findViewById(R.id.tvLotSize);
        tvUnits      = v.findViewById(R.id.tvUnits);
        tvPipValue   = v.findViewById(R.id.tvPipValue);
        tvRrr        = v.findViewById(R.id.tvRrrCalc);
        tvEv         = v.findViewById(R.id.tvEv);
        tvKelly      = v.findViewById(R.id.tvKelly);

        String[] pairs = {"EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD","NZD/USD","EUR/GBP","USD/CHF"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_spinner_item, pairs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPair.setAdapter(adapter);

        btnCalculate.setOnClickListener(x -> calculate());
        return v;
    }

    private void calculate() {
        try {
            double balance  = Double.parseDouble(etBalance.getText().toString());
            double riskPct  = Double.parseDouble(etRisk.getText().toString());
            double slPips   = Double.parseDouble(etSl.getText().toString());
            double tpPips   = Double.parseDouble(etTp.getText().toString());
            double entry    = etEntry.getText().toString().isEmpty() ? 1.0
                            : Double.parseDouble(etEntry.getText().toString());

            String pair  = (String) spinnerPair.getSelectedItem();
            boolean isJpy = pair.contains("JPY");
            double pipValue = isJpy ? 1000.0 / entry : 10.0; // per standard lot

            double riskAmount = balance * (riskPct / 100.0);
            double lotSize    = ForexMathEngine.positionSize(balance, riskPct, slPips, pipValue);
            double units      = lotSize * 100_000;
            double actualPipV = riskAmount / slPips;

            double tp = entry + tpPips * (isJpy ? 0.01 : 0.0001);
            double sl = entry - slPips * (isJpy ? 0.01 : 0.0001);
            double rrr = ForexMathEngine.riskRewardRatio(entry, tp, sl);

            // Expected Value (assume 55% win rate)
            double winRate = 0.55;
            double ev = ForexMathEngine.expectedValue(winRate, tpPips * actualPipV, slPips * actualPipV);
            double kelly = ForexMathEngine.kellyCriterion(winRate, rrr);

            tvRiskAmount.setText(String.format("$%.2f", riskAmount));
            tvLotSize.setText(String.format("%.2f lots", lotSize));
            tvUnits.setText(String.format("%,d units", (long) units));
            tvPipValue.setText(String.format("$%.2f / pip", actualPipV));
            tvRrr.setText(String.format("1 : %.2f", rrr));
            tvEv.setText(String.format("$%.2f per trade", ev));
            tvKelly.setText(String.format("%.1f%% of account", kelly * 100));

        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "Please fill all fields correctly", Toast.LENGTH_SHORT).show();
        }
    }
}
