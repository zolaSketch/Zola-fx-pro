# ForexPro Analyzer - Android Studio Project
## AI-Powered Forex Signal Generator v2.0

### ፕሮጀክቱን Android Studio ላይ እንዴት ይከፈታል

1. Android Studio ይክፈቱ
2. "Open an Existing Project" ምረጡ
3. ይህን ፎልደር ምረጡ: `ForexProAndroid/`
4. Gradle sync ሲጨርስ ይጠብቁ
5. Run ▶️ button ይጫኑ

---

## 📁 Project Structure

```
ForexProAndroid/
├── app/src/main/java/com/forexpro/analyzer/
│   ├── engine/
│   │   ├── ForexMathEngine.java     ← ሁሉም ሂሳብ ቀመሮች
│   │   └── SignalEngine.java        ← Signal generator
│   ├── sentiment/
│   │   └── SentimentAnalyzer.java  ← Online+Offline NLP
│   ├── activities/
│   │   ├── MainActivity.java
│   │   ├── SplashActivity.java
│   │   └── SettingsActivity.java
│   ├── fragments/
│   │   ├── SignalsFragment.java     ← Main signals + chart
│   │   ├── ScannerFragment.java    ← Scan all pairs
│   │   ├── SentimentFragment.java  ← News sentiment
│   │   ├── RiskFragment.java       ← Position calculator
│   │   └── NewsFragment.java       ← Economic news
│   ├── models/
│   │   ├── ForexSignal.java
│   │   └── SentimentResult.java
│   ├── notifications/
│   │   ├── SignalMonitorService.java ← Background monitoring
│   │   └── BootReceiver.java
│   └── utils/
│       └── PreferenceManager.java
```

---

## 🧮 Forex Math Formulas Included

### Calculus (ካልኩለስ)
- `derivative()` - First order numerical derivative
- `secondDerivative()` - Acceleration/deceleration
- `integrate()` - Trapezoidal integration (area under curve)
- `limit()` - Limit approximation

### Slope & Regression (ስሎፕ)
- `slope()` - Linear slope of price series
- `linearRegression()` - Best fit line [slope, intercept]
- `rSquared()` - Coefficient of determination (R²)
- `trendAngle()` - Angle in degrees

### Moving Averages
- `sma()` - Simple Moving Average
- `ema()` - Exponential Moving Average
- `wma()` - Weighted Moving Average
- `hma()` - Hull Moving Average

### Technical Indicators
- `rsi()` - RSI (14)
- `stochasticRSI()` - Stochastic RSI
- `macd()` - MACD (12,26,9) → [line, signal, histogram]
- `bollingerBands()` - [upper, mid, lower, bandwidth, %B]
- `atr()` - Average True Range
- `adx()` - ADX + ±DI
- `stochastic()` - %K, %D
- `cci()` - Commodity Channel Index
- `williamsR()` - Williams %R
- `ichimoku()` - Full Ichimoku Cloud

### Fibonacci
- `fibonacciRetracement()` - 0%, 23.6%, 38.2%, 50%, 61.8%, 76.4%, 100%
- `fibonacciExtension()` - 127.2%, 161.8%, 200%, 261.8%

### Pivot Points
- `classicPivot()` - PP, R1-R3, S1-S3
- `camarillaPivot()` - PP, R1-R4, S1-S4
- `woodiePivot()` - PP, R1-R2, S1-S2

### Statistics
- `mean()`, `variance()`, `standardDeviation()`
- `correlation()` - Pearson correlation coefficient
- `zScore()` - Z-score

### Options / Derivatives
- `blackScholesCall()` - Black-Scholes call price
- `blackScholesPut()` - Black-Scholes put price
- `normalCDF()` - Normal distribution CDF

### Risk Management
- `positionSize()` - Lot size calculator
- `riskRewardRatio()` - R:R
- `expectedValue()` - EV per trade
- `kellyCriterion()` - Optimal bet size
- `maxDrawdown()` - Maximum drawdown %
- `sharpeRatio()` - Risk-adjusted return

---

## 🛠️ Dependencies (build.gradle)
- MPAndroidChart v3.1.0 (charts)
- Retrofit2 (API calls)
- Firebase FCM (push notifications)
- Material Components
- WorkManager (background tasks)

---

## 🌍 Languages
- English (default)
- አማርኛ (Amharic) - values-am/strings.xml

## 🎨 Features
- ✅ Dark theme (professional trading UI)
- ✅ Push notifications for high-confidence signals
- ✅ Online + Offline sentiment analysis
- ✅ War/geopolitical news impact analysis
- ✅ 10 currency pairs
- ✅ 4 timeframes (M15, H1, H4, D1)
- ✅ All Fibonacci levels
- ✅ Pivot points (Classic, Camarilla, Woodie)
- ✅ Full Ichimoku Cloud
- ✅ Kelly Criterion + Sharpe Ratio
- ✅ Black-Scholes options pricing
